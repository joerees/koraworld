<script setup lang="ts">
  import KoraMidi from '../components/KoraMidi.vue'
</script>

<template>
  <main> 
    
    <KoraMidi />
  </main>
</template>

